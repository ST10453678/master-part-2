import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert, FlatList, Button } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';

// Create a stack navigator
const Stack = createNativeStackNavigator();

// SignUpSignInScreen Component
const SignUpSignInScreen = ({ navigation }) => {
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');

  const handleSignUp = () => {
    if (signUpEmail === '' || signUpPassword === '') {
      Alert.alert('Error', 'Please fill in all fields to sign up.');
    } else {
      Alert.alert('Success', 'Sign Up Successful');
      navigation.navigate('Menu'); // Navigate to Menu after sign up
    }
  };

  const handleSignIn = () => {
    if (signInEmail === '' || signInPassword === '') {
      Alert.alert('Error', 'Please fill in all fields to sign in.');
    } else {
      navigation.navigate('Menu'); // Navigate to Menu after sign in
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sign Up</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        value={signUpEmail}
        onChangeText={setSignUpEmail}
        placeholderTextColor="#888"
      />
      <TextInput
        style={styles.input}
        placeholder="Create Password"
        value={signUpPassword}
        onChangeText={setSignUpPassword}
        secureTextEntry
        placeholderTextColor="#888"
      />
      <TouchableOpacity style={styles.button} onPress={handleSignUp}>
        <Text style={styles.buttonText}>Sign Up</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Sign In</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        value={signInEmail}
        onChangeText={setSignInEmail}
        placeholderTextColor="#888"
      />
      <TextInput
        style={styles.input}
        placeholder="Enter Password"
        value={signInPassword}
        onChangeText={setSignInPassword}
        secureTextEntry
        placeholderTextColor="#888"
      />
      <TouchableOpacity style={styles.button} onPress={handleSignIn}>
        <Text style={styles.buttonText}>Sign In</Text>
      </TouchableOpacity>
    </View>
  );
};

// Menu Items Data
const menuItems = [
  { id: '1', name: 'Fried Potato', price: 150, category: 'Starters' },
  { id: '2', name: 'Rolled Bread baked beans', price: 300, category: 'Starters' },
  { id: '3', name: 'Spaghetti', price: 750, category: 'Main Dish' },
  { id: '4', name: 'Pap, cabbage & Chicken', price: 1500, category: 'Main Dish' },
  { id: '5', name: 'Chocolate Ice Cream', price: 850, category: 'Dessert' },
  { id: '6', name: 'Chocolate Cake', price: 600, category: 'Dessert' },
];

// MenuScreen Component
const MenuScreen = ({ navigation }) => {
  const [totalPrice, setTotalPrice] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMenu = menuItems.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const addToCart = (price) => {
    setTotalPrice(totalPrice + price);
  };

  const handleCashOut = (price) => {
    Alert.alert('Cashout', `You have cashed out R${price}.`);
    setTotalPrice(0); // Reset cart after cashing out
  };

  const renderCategory = (category) => {
    return (
      <>
        <Text style={styles.categoryTitle}>{category}</Text>
        <FlatList
          data={filteredMenu.filter(item => item.category === category)}
          keyExtractor={(item) => item.id}
          numColumns={2}  // Show two items per row
          renderItem={({ item }) => (
            <View style={styles.menuItem}>
              <Text style={styles.menuText}>{item.name}</Text>
              <Text style={styles.menuText}>R{item.price}</Text>

              {/* Add to Cart Button */}
              <TouchableOpacity style={styles.addButton} onPress={() => addToCart(item.price)}>
                <Text style={styles.buttonText}>Add Cart</Text>
              </TouchableOpacity>

              {/* Cashout Button */}
              <TouchableOpacity style={styles.cashoutButton} onPress={() => handleCashOut(item.price)}>
                <Text style={styles.buttonText}>Cashout</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      </>
    );
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search for dishes..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
      
      {renderCategory('Starters')}
      {renderCategory('Main Dish')}
      {renderCategory('Dessert')}

      <Text style={styles.totalPrice}>Total Price: R{totalPrice}</Text>
      <Button title="Proceed to Payment" onPress={() => navigation.navigate('Payment', { totalPrice })} />
    </View>
  );
};

// PaymentScreen Component
const PaymentScreen = ({ route, navigation }) => {
  const { totalPrice } = route.params;
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');

  const handlePayment = () => {
    if (!selectedPaymentMethod) {
      Alert.alert('Error', 'Please select a payment method.');
    } else {
      Alert.alert('Success', `Payment of R${totalPrice} was successful via ${selectedPaymentMethod}!`);
      navigation.navigate('SignUpSignIn'); // Navigate back to Sign-Up/Sign-In
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Payment</Text>
      <Text style={styles.subtitle}>Total Amount: R{totalPrice}</Text>

      <Text style={styles.label}>Select Payment Method:</Text>
      {['Credit Card', 'PayPal', 'Cash'].map((method) => (
        <TouchableOpacity
          key={method}
          style={selectedPaymentMethod === method ? styles.selectedPaymentButton : styles.paymentButton}
          onPress={() => setSelectedPaymentMethod(method)}
        >
          <Text style={styles.paymentText}>{method}</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.button} onPress={handlePayment}>
        <Text style={styles.buttonText}>Pay Now</Text>
      </TouchableOpacity>
    </View>
  );
};

// App Component
const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="SignUpSignIn">
        <Stack.Screen name="SignUpSignIn" component={SignUpSignInScreen} />
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="Payment" component={PaymentScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 10,
  },
  searchInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingLeft: 8,
    marginBottom: 20,
  },
  categoryTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',
    color: '#333',
  },
  menuItem: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  menuText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  addButton: {
    backgroundColor: '#2196F3',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  cashoutButton: {
    backgroundColor: '#FF6347',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',
  },
  selectedPaymentButton: {
    padding: 10,
    backgroundColor: '#2196F3',
    borderRadius: 5,
    marginVertical: 5,
  },
  paymentButton: {
    padding: 10,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
    marginVertical: 5,
  },
  paymentText: {
    color: '#333',
    textAlign: 'center',
  },
  button: {
    width: '80%',
    padding: 15,
    backgroundColor: '#2196F3',
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  subtitle: {
    fontSize: 20,
    marginVertical: 10,
    color: '#333',
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
    color: '#333',
  },
});

// Export the App component
export default App;


